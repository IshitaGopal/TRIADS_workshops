# Transdisciplinary Institute in Applied Data Sciences Training Series 

## Introduction to Text Analysis 

### Google Colab Notebooks:
- [Day 1 - Working with strings](https://colab.research.google.com/drive/1RxcNLqLsAxl25CBdaRcdBtTFUKorCF1T?usp=sharing)
- [Day 2 - Bag of Words](https://colab.research.google.com/drive/1Ku1NDJ5dlnyeB_xcIaPPz8Wl4r-gp_7E#scrollTo=sy0I6-OWqYvA)
- [Day 3 - Dictionary Analysis](https://colab.research.google.com/drive/1TCQkKNAaXBpd7TRnBjc27vailQgj5Qs5?usp=sharing)
- [Day 4 - Classification](https://colab.research.google.com/drive/14ZMpLiNp-rB33gXacP8Wdj_jcYNUUv68?usp=sharing)


